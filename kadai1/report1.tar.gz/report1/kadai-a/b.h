#ifndef B_H_INCLUDED
#define B_H_INCLUDED

int mystrcmp(const char*a, const char *b);

#endif
