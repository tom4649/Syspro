#pragma once
void init_tasks();
void schedule(unsigned long long sp);
