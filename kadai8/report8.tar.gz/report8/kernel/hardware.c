#include "hardware.h"

struct HardwareInfo hardware_info;
