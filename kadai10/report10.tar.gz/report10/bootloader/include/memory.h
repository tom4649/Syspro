#pragma once
#include <efi.h>

void exit_boot_services(EFI_HANDLE ImageHandle);
