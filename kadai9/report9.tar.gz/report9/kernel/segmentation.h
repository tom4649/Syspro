#pragma once
void init_segmentation();
